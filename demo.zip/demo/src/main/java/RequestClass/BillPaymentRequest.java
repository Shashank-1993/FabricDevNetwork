package RequestClass;

import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.validation.annotation.Validated;

import java.util.Objects;


/**
 * BillPaymentRequest
 */
@Validated
@Getter
@Setter
@EqualsAndHashCode
@ToString(callSuper = true)
public class BillPaymentRequest   {

    @JsonProperty("agentId")
    private String agentId = null;

    @JsonProperty("amount")
    private String amount = null;

    @JsonProperty("billId")
    private String billId = null;

    @JsonProperty("consumerAccountId")
    private String consumerAccountId = null;

    @JsonProperty("consumerName")
    private String consumerName = null;

    @JsonProperty("discom")
    private String discom = null;

    @JsonProperty("division")
    private String division = null;

    @JsonProperty("divisionCode")
    private String divisionCode = null;

    @JsonProperty("mobile")
    private String mobile = null;

    @JsonProperty("referenceTransactionId")
    private String referenceTransactionId = null;

    @JsonProperty("sourceType")
    private String sourceType = null;

    @JsonProperty("type")
    private String type = null;

    @JsonProperty("vanNo")
    private String vanNo = null;

    @JsonProperty("walletId")
    private String walletId = null;

}