package RequestClass;

public class EnrollRegisterClientUserRequest {
}
