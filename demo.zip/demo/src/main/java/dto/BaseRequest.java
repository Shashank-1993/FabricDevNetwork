package dto;

import enums.EntityType;
import enums.TransactionType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

//import javax.validation.constraints.NotNull;

@Getter
@Setter
@ToString(callSuper = true)
public abstract class BaseRequest {

//    @NotNull(message = "External transaction id is required")
    private String externalTransactionId;

//    @NotNull(message = "Transaction id is required")
    private String transactionId;

//    @NotNull(message = "Transaction type is required")
    private TransactionType transactionType;

//    @NotNull(message = "Amount is required")
    private double amount;

//    @NotNull(message = "Entity id is required")
    private String entityId;

//    @NotNull(message = "Entity type is required")
    private EntityType entityType;

    private String externalId;

    private String mobile;

    private String discom;

    private String division;

    private boolean audit = true;

}

