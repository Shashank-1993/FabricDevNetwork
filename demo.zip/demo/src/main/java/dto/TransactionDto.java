package dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.validation.annotation.Validated;

//import javax.validation.constraints.NotNull;

@Getter
@Setter
@ToString(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)

public class TransactionDto extends BaseRequest implements Comparable<TransactionDto> {

//    @NotNull(message = "Van id is required")
    private String vanId;
    private long transactionTime;
    private String id;
//    @NotNull(message = "Activity is required")
    private String activity;
    private String agencyId;
    private String billId;
    protected String consumerId;

    @Override
    public int compareTo(final TransactionDto other) {
        return Long.compare(other.transactionTime, this.transactionTime);
    }
}