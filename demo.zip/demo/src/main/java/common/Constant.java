package common;

public final class Constant {
    private Constant() {
    }

    public static final String FIELD_TRANSACTION_TIME = "transactionTime";
    public static final String FIELD_TRANSACTION_ID = "transactionId";
    public static final String FIELD_EXTERNAL_TRANSACTION_ID = "externalTransactionId";
    public static final String FIELD_BILL_ID = "billId";
    public static final String FIELD_VAN_ID = "vanId";
    public static final String FIELD_CONSUMER_ID = "consumerId";
    public static final String FIELD_TRANSACTION_TYPE = "transactionType";
    public static final String FIELD_ACTIVITY = "activity";
    public static final String FIELD_DISCOM = "discom";
    public static final String FIELD_DIVISION = "division";
}

