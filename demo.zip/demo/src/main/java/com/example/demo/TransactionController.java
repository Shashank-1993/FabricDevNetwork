package com.example.demo;

import com.fasterxml.jackson.core.JsonProcessingException;
import dto.TransactionQueryResponse;
import fabricjavaclient.WalletCredit;
import org.hyperledger.fabric.gateway.ContractException;
import org.hyperledger.fabric.gateway.Wallet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import services.TransactionService;


import java.util.Optional;
import java.util.concurrent.TimeoutException;

@Component
@RestController
@RequestMapping("/transaction")
public class TransactionController {


//    private TransactionService transactionService;

//    @Autowired
//    private WalletService walletService;

//    public TransactionController(final TransactionService transactionService) {
//        this.transactionService = transactionService;
//    }

//    @PostMapping
//    public ResponseEntity<TransactionDto> create(@Valid @RequestBody final TransactionDto transactionDto) throws InterruptedException, TimeoutException, ContractException {
//        return new ResponseEntity<>(transactionService.create(transactionDto), HttpStatus.CREATED);
//    }

    @GetMapping(path = "/{transactionId}")
    public ResponseEntity<Optional<TransactionQueryResponse>> getTransactionId(
            @PathVariable("transactionId") final String transactionId) throws JsonProcessingException, ContractException {
        System.out.println("In Controller " + transactionId);
        TransactionService transactionService = new TransactionService();
        return new ResponseEntity<>(transactionService.getTransactionForId(transactionId), HttpStatus.OK);
    }

//    @GetMapping
//    public ResponseEntity<Optional<TransactionQueryResponse>> getTransactionForCriteria(
//            @RequestParam(value = "search") final String queryString,
//            @RequestParam(value = "pageSize", required = false) final Integer pageSize,
//            @RequestParam(value = "nextPageToken", required = false) final String bookMark) throws JsonProcessingException, ContractException {
//        final Optional<TransactionQueryResponse> result;
//        if (pageSize == null && bookMark == null) {
//            result = transactionService.getTransactionForCriteria(queryString, 10, "");
//        } else if (pageSize == null) {
//            result = transactionService.getTransactionForCriteria(queryString, 10, bookMark);
//        } else if (bookMark == null) {
//            result = transactionService.getTransactionForCriteria(queryString, pageSize, "");
//        } else {
//            result = transactionService.getTransactionForCriteria(queryString, pageSize, bookMark);
//        }
//        return new ResponseEntity<>(result, HttpStatus.OK);
//    }
//
//    @PostMapping("/transfer")
//    public ResponseEntity<HttpStatus> transfer(@Valid @RequestBody final TransferRequest transferRequest) throws InterruptedException, TimeoutException, ContractException {
//        walletService.transfer(transferRequest);
//        return new ResponseEntity<>(HttpStatus.CREATED);
//    }
//
//    @PostMapping("/deposit")
//    public ResponseEntity<HttpStatus> deposit(@Valid @RequestBody final DepositRequest depositRequest) throws ApiException {
//        walletService.deposit(depositRequest);
//        return new ResponseEntity<>(HttpStatus.CREATED);
//    }
//
//    @PostMapping("/withdraw")
//    public ResponseEntity<HttpStatus> withdraw(@Valid @RequestBody final WithdrawRequest withdrawRequest) throws InterruptedException, TimeoutException, ContractException {
//        walletService.withdraw(withdrawRequest);
//        return new ResponseEntity<>(HttpStatus.CREATED);
//    }

    @GetMapping("/test")
    public ResponseEntity<HttpStatus> test() throws Exception {

        WalletCredit walletCredit = new WalletCredit();
        walletCredit.test();
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
