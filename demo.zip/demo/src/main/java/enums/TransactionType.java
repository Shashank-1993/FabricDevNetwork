package enums;

public enum TransactionType {
    BANK,
    COMMISSION,
    WALLET,
    RAPDRP,
    NON_RAPDRP;
}