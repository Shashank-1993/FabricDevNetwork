package enums;

public enum EntityType {

    AGENT,
    AGENCY,
    OWNER;

}
