package services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import dto.TransactionDto;
import dto.TransactionQueryResponse;
import org.hyperledger.fabric.gateway.ContractException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Optional;

import static org.apache.logging.log4j.util.Strings.isNotBlank;

@Service
public class TransactionService extends AbstractService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TransactionService.class);

    private static final String DOC_TYPE_FILTER = "docType==transaction ";

    private static final String CONTRACT_NAME = "com.tequre.blockchain.transaction";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static {
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        MAPPER.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
    }

    public Optional<TransactionQueryResponse> getTransactionForId(final String transactionId) throws JsonProcessingException, ContractException {
        final String query = String.format("transactionId==%s", transactionId);
        return getTransactionForCriteria(query, 10, "");
    }

    public Optional<TransactionQueryResponse> getTransactionForCriteria(final String queryString, final int pageSize, final String bookMark) throws ContractException, JsonProcessingException {

        final ObjectNode queryNode;
        if (isNotBlank(queryString)) {
            queryNode = prepareQuery(DOC_TYPE_FILTER + "and " + queryString, TransactionDto.class);
        } else {
            queryNode = prepareQuery(DOC_TYPE_FILTER, TransactionDto.class);
        }
        Optional<TransactionQueryResponse> transactionQueryResponseOptional = Optional.empty(); //doubt

        LOGGER.debug("Invoking query : {}", queryNode);
        final String payloadStr = queryChaincode("query", queryNode.toString(), String.valueOf(pageSize), bookMark);
        if (isNotBlank(payloadStr)) {
            transactionQueryResponseOptional = Optional.of(MAPPER.readValue(payloadStr, TransactionQueryResponse.class));
            final TransactionQueryResponse transactionQueryResponse = transactionQueryResponseOptional.get();
            Collections.sort(transactionQueryResponse.getResult());
            transactionQueryResponseOptional = Optional.of(transactionQueryResponse);
        }

        LOGGER.debug("Got response : {}", transactionQueryResponseOptional);
        return transactionQueryResponseOptional;
    }

    @Override
    protected String getContractName() {
        return CONTRACT_NAME;
    }
}
