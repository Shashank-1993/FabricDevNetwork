package services;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import cz.jirutka.rsql.parser.RSQLParser;
import cz.jirutka.rsql.parser.ast.Node;
import org.hyperledger.fabric.gateway.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.ReflectionUtils;
import search.parser.CustomRsqlVisitor;
import search.parser.RsqlJsonNodeBuilder;

import java.io.IOException;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Set;

import static com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;
import static common.Constant.*;

public abstract class AbstractService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractService.class);

    @Autowired
    private Network network;

    @Value("#{environment.CHAIN_CODE_NAME}")
    private String chainCodeName;

    protected abstract String getContractName();

    protected Contract getContract() {
        return network.getContract(chainCodeName, getContractName());
    }

    ObjectNode prepareQuery(final String queryString, final Class<?> type) {
        LOGGER.debug("Received a query from search request : {}", queryString);
        final RsqlJsonNodeBuilder builder = new RsqlJsonNodeBuilder(type);
        builder.init();
        final CustomRsqlVisitor customRsqlVisitor = new CustomRsqlVisitor();
        customRsqlVisitor.setRsqlJsonNodeBuilder(builder);
        final ObjectNode queryNode = instance.objectNode();
        final JsonNode jsonNode;
        final Node node = new RSQLParser().parse(queryString);
        jsonNode = node.accept(customRsqlVisitor);
        queryNode.set("selector", jsonNode);
        final JsonNode index = prepareIndexField(builder);
        if (!index.isEmpty()) {
            queryNode.set("use_index", index);
        }
        final ArrayNode fieldNamesNode = instance.arrayNode();
        ReflectionUtils.doWithFields(type, f -> fieldNamesNode.add(f.getName()), f -> !Modifier.isStatic(f.getModifiers()));
        queryNode.set("fields", fieldNamesNode);
        return queryNode;
    }

    protected JsonNode prepareIndexField(final RsqlJsonNodeBuilder builder) {
        final ArrayNode arrayNode = instance.arrayNode();
        final Set<String> comparisonFields = builder.getComparisonFields();
        final StringBuilder indexBuilder = new StringBuilder("_design/");
        if ((comparisonFields.contains(FIELD_DISCOM.toLowerCase()) || comparisonFields.contains(FIELD_DIVISION.toLowerCase())) && comparisonFields.contains(FIELD_TRANSACTION_TIME.toLowerCase())) {

            if (comparisonFields.contains(FIELD_VAN_ID.toLowerCase())) {
                if (comparisonFields.contains(FIELD_DISCOM.toLowerCase())) {
                    indexBuilder.append("discomdoctypetransactiontimevanid");
                } else if (comparisonFields.contains(FIELD_DIVISION.toLowerCase())) {
                    indexBuilder.append("divisiondoctypetransactiontimevanid");
                }
            } else {
                if (comparisonFields.contains(FIELD_DISCOM.toLowerCase())) {
                    indexBuilder.append("discomdoctypetransactiontime");
                } else if (comparisonFields.contains(FIELD_DIVISION.toLowerCase())) {
                    indexBuilder.append("divisiondoctypetransactiontime");
                }
            }
            LOGGER.info("Selected index is [{}]", indexBuilder);
        } else {
            for (String comparisonField : comparisonFields) {
                indexBuilder.append(comparisonField);
            }
        }
        indexBuilder.append("idxdoc");
        arrayNode.add(indexBuilder.toString());
        return arrayNode;
    }


    protected String queryChaincode(final String funcName, final String... args) throws ContractException {
        final Contract contract = getContract();
        final Transaction transaction = contract.createTransaction(funcName);
        final byte[] bytes = transaction.evaluate(args);
        final String result = new String(bytes, StandardCharsets.UTF_8);
        LOGGER.info("Received result {}", result);
        return result;
    }
}
