package xtras;

import org.apache.commons.io.FileUtils;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class conversion {

    public static void main(String[] args) {

        byte[] pdfRawData;
            try {
                pdfRawData = FileUtils.readFileToByteArray(new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/qwerty.pdf"));
//                String pdfStr = new String(pdfRawData);
//                String pdfStr = pdfRawData.toString();


                BASE64Encoder encoder = new BASE64Encoder();
//                String encodedPdf = encoder.encode(pdfStr.getBytes());
                String encodedPdf = encoder.encode(pdfRawData);
//                System.out.println(encodedPdf);


                BASE64Decoder decoder = new BASE64Decoder();

//                System.out.println(pdfStr);
//                byte [] raw = pdfStr.getBytes();
//                FileUtils.writeByteArrayToFile(new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/output.pdf") , raw);
                FileUtils.writeByteArrayToFile(new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/output.pdf") , decoder.decodeBuffer(encodedPdf));
            } catch (IOException e) {
                e.printStackTrace();
            }


    }





//My data is available in the form of String

//


// Decode the encoded content to test


//

}
