package xtras;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class pdfToByte {

    public static void main(String[] args) {
        File pdfFile = new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/qwerty.pdf");
        byte[] pdfData = new byte[(int) pdfFile.length()];
        System.out.println("dekho"+pdfData.toString());

        pdfToByte pdfToByte = new pdfToByte();
        pdfToByte.byteArrayToFile(pdfData);

    }


    public void byteArrayToFile(byte[] bArray) {
        try {
            // Create file
            FileWriter fstream = new FileWriter("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/out.txt");
            BufferedWriter out = new BufferedWriter(fstream);
            for (Byte b: bArray) {
                out.write(b);
            }
            out.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }



}
