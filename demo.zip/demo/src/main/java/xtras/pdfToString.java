//package xtras;
//
//import org.apache.pdfbox.cos.COSDocument;
//import org.apache.pdfbox.io.RandomAccessFile;
//import org.apache.pdfbox.pdfparser.PDFParser;
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//
//import java.io.File;
//import java.io.IOException;
//import java.io.PrintWriter;
//
//public class pdfToString {
//
//    public static void main(String[] args) {
//        File f = new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/qwerty.pdf");
//        String parsedText;
//        PDFParser parser;
//
//        {
//            try {
//                parser = new PDFParser(new RandomAccessFile(f, "r"));
//                parser.parse();
//
//                COSDocument cosDoc = parser.getDocument();
//                PDFTextStripper pdfStripper = new PDFTextStripper();
//                PDDocument pdDoc = new PDDocument(cosDoc);
//                parsedText = pdfStripper.getText(pdDoc);
//                System.out.println(parsedText);
//
//                PrintWriter pw = new PrintWriter("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/pdf.txt");
//                pw.print(parsedText);
//                pw.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
