package xtras;


import org.apache.tomcat.util.json.JSONParser;
import org.json.JSONArray;
import org.json.JSONObject;

public class ConvertJSON {

    public static void main(String[] args) {
        String str = "[{\"RegistrationNumber\":\"ChILDREG20210531172541\",\"ChildName\":\"hemant raghav\",\"Gender\":\"Male\",\"DateOfBirth\":\"2021-06-02\",\"TimeOfBirth\":\"17:28\",\"CityOfBirth\":\"Gurgaon\",\"CountryOfBirth\":\"India\",\"ChildAadharNumber\":\"\",\"MotherName\":\"fddasf\",\"FatherName\":\"Shyam Das\",\"MotherAadharNumber\":\"5245435457\",\"FatherAadharNumber\":\"\",\"GurdianAadharNumber\":\"\",\"Address\":\"South City\",\"City\":\"Gurgaon\",\"State\":\"Haryana\",\"Country\":\"India\",\"Religion\":\"Hinduism\",\"PostalCode\":\"221009\",\"CreatedBy\":\"2021-05-31 17:25:41.0\",\"CreatedAt\":\"user\",\"ModifiedAt\":\"Wed Jun 02 11:42:28 IST 2021\",\"ModifiedBy\":\"admin\",\"Status\":\"APPROVED\",\"DocHash\":\"122df84196bc47bf1103bede816fce50cc69c34b91c0a6a22d7fe3c4771fb47b\"}]";

        str = str.replaceAll("\\[", "").replaceAll("\\]","");
        System.out.println(str);

        JSONObject jsonObject = new JSONObject(str);
        String value = jsonObject.getString("ChildName");
        System.out.println(value);


//        JSONObject object = new JSONObject(s);
//
//        JSONObject getObject = object.getJSONObject("record");
////        JSONArray getArray = getObject.getJSONArray("JArray1");
//
//        for(int i = 0; i < getObject.length(); i++)
//        {
//            String str = getObject.get("record").toString();
//            System.out.println(str);
//            //Iterate through the elements of the array i.
//            //Get thier value.
//            //Get the value for the first element and the value for the last element.
//        }
    }



}
