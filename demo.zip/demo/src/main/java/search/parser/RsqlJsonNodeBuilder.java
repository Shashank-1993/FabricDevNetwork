package search.parser;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import cz.jirutka.rsql.parser.ast.ComparisonNode;
import cz.jirutka.rsql.parser.ast.ComparisonOperator;
import cz.jirutka.rsql.parser.ast.LogicalNode;
import cz.jirutka.rsql.parser.ast.LogicalOperator;
import cz.jirutka.rsql.parser.ast.Node;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

import static com.fasterxml.jackson.databind.node.JsonNodeFactory.instance;

public class RsqlJsonNodeBuilder {

    private final Class<?> type;

    private final Set<String> comparisonFields = new TreeSet<>(String::compareToIgnoreCase);
    private Map<String, ? extends Class<?>> nameAndTypeMapping;

    public RsqlJsonNodeBuilder(final Class<?> type) {
        this.type = type;
    }

    private JsonNode createSpecification(final Node node) {
        if (node instanceof LogicalNode) {
            return createSpecification((LogicalNode) node);
        }
        if (node instanceof ComparisonNode) {
            return createSpecification(((ComparisonNode) node));
        }
        return null;
    }

    JsonNode createSpecification(final LogicalNode logicalNode) {
        final List<JsonNode> list = logicalNode.getChildren()
                .stream()
                .map(this::createSpecification)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        final ArrayNode arrayNode = instance.arrayNode();
        list.forEach(arrayNode::add);
        final ObjectNode result = instance.objectNode();
        if (logicalNode.getOperator() == LogicalOperator.AND) {
            result.set("$and", arrayNode);
        } else if (logicalNode.getOperator() == LogicalOperator.OR) {
            result.set("$or", arrayNode);
        }
        return result;
    }

    JsonNode createSpecification(final ComparisonNode comparisonNode) {
        final ComparisonOperator operator = comparisonNode.getOperator();
        final String selector = comparisonNode.getSelector();

        final List<String> arguments = comparisonNode.getArguments();
        final String argument = arguments.get(0);

        comparisonFields.add(selector.toLowerCase());
        switch (Objects.requireNonNull(RsqlSearchOperation.getSimpleOperator(operator))) {

            case EQUAL: {
                return populateValue(selector, argument, "$eq");
            }
            case NOT_EQUAL: {
                return populateValue(selector, argument, "$ne");
            }
            case GREATER_THAN: {
                return populateValue(selector, argument, "$gt");
            }
            case GREATER_THAN_OR_EQUAL: {
                return populateValue(selector, argument, "$gte");
            }
            case LESS_THAN: {
                return populateValue(selector, argument, "$lt");
            }
            case LESS_THAN_OR_EQUAL: {
                return populateValue(selector, argument, "$lte");
            }
            case IN: {
                final ArrayNode arrayNode = instance.arrayNode();
                arguments.forEach(arrayNode::add);
                return instance.objectNode().set(selector, instance.objectNode().set("$in", arrayNode));
            }
            case NOT_IN: {
                final ArrayNode arrayNode = instance.arrayNode();
                arguments.forEach(arrayNode::add);
                return instance.objectNode().set(selector, instance.objectNode().set("$nin", arrayNode));
            }
        }
        return null;
    }

    private JsonNode populateValue(final String selector, final String val, final String comparisonOperator) {
        if (StringUtils.isNotBlank(val)) {
            final Class<?> fieldType = nameAndTypeMapping.get(selector.toLowerCase());
            if (fieldType != null) {
                if (Integer.class.equals(fieldType) || Integer.TYPE.equals(fieldType)) {
                    return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, Integer.parseInt(val)));
                } else if (Long.class.equals(fieldType) || Long.TYPE.equals(fieldType)) {
                    return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, Long.parseLong(val)));
                } else if (Float.class.equals(fieldType) || Float.TYPE.equals(fieldType)) {
                    return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, Float.parseFloat(val)));
                } else if (Double.class.equals(fieldType) || Double.TYPE.equals(fieldType)) {
                    return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, Double.parseDouble(val)));
                } else if (Boolean.class.equals(fieldType)) {
                    return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, Boolean.parseBoolean(val)));
                } else {
                    return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, val));
                }
            } else {
                return instance.objectNode().set(selector, instance.objectNode().put(comparisonOperator, val));
            }
        } else {
            return instance.objectNode().set(selector, instance.objectNode().set(comparisonOperator, NullNode.instance));
        }
    }

    public Set<String> getComparisonFields() {
        return comparisonFields;
    }

    public void init() {
        nameAndTypeMapping = Arrays.stream(type.getDeclaredFields()).collect(Collectors.toMap(f -> f.getName().toLowerCase(), Field::getType));
    }
}
