package search.parser;

import com.fasterxml.jackson.databind.JsonNode;
import cz.jirutka.rsql.parser.ast.AndNode;
import cz.jirutka.rsql.parser.ast.ComparisonNode;
import cz.jirutka.rsql.parser.ast.NoArgRSQLVisitorAdapter;
import cz.jirutka.rsql.parser.ast.OrNode;

public class CustomRsqlVisitor extends NoArgRSQLVisitorAdapter<JsonNode> {

    private RsqlJsonNodeBuilder rsqlJsonNodeBuilder;

    public void setRsqlJsonNodeBuilder(RsqlJsonNodeBuilder rsqlJsonNodeBuilder) {
        this.rsqlJsonNodeBuilder = rsqlJsonNodeBuilder;
    }

    @Override
    public JsonNode visit(AndNode node) {
        return rsqlJsonNodeBuilder.createSpecification(node);
    }

    @Override
    public JsonNode visit(OrNode node) {
        return rsqlJsonNodeBuilder.createSpecification(node);
    }

    @Override
    public JsonNode visit(ComparisonNode node) {
        return rsqlJsonNodeBuilder.createSpecification(node);
    }
}
