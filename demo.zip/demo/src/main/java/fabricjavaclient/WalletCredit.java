package fabricjavaclient;

import org.apache.commons.io.FileUtils;
import org.hyperledger.fabric.gateway.*;
import org.json.JSONObject;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import xtras.pdfHash;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.Date;

public class WalletCredit {

    static {
        System.setProperty("org.hyperledger.fabric.sdk.service_discovery.as_localhost", "true");
    }

    public String walletCreditSubmit(String UID,
                                     String agentId,
                                     String amount,
                                     String sourceType,
                                     String transactionId,
                                     String walletId) throws Exception {

        // Load a file system based wallet for managing identities.
        Path walletPath = Paths.get("wallet");
        Wallet wallet = Wallets.newFileSystemWallet(walletPath);
        // load a CCP
        Path networkConfigPath = Paths.
                get("/Users/shashankawasthi/Documents/Project/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.yaml");
        Gateway.Builder builder = Gateway.createBuilder();
        builder.identity(wallet, "appUser").networkConfig(networkConfigPath).discovery(true);

        // create a gateway connection
        try (Gateway gateway = builder.connect()) {

            // get the network and contract

            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("basic");

            contract.submitTransaction("walletCreditTrxn", UID, agentId, amount, sourceType, transactionId, walletId);

            System.out.println("Wallet Credit Transaction Successfullt committed to ledger");

            return "Wallet Credit Transaction Successfully committed to ledger";

        }

    }

    public String queryTrxnByTrxnId(String transactionId) throws Exception {

        // Load a file system based wallet for managing identities.
        Path walletPath = Paths.get("wallet");
        Wallet wallet = Wallets.newFileSystemWallet(walletPath);
        // load a CCP
        Path networkConfigPath = Paths.
                get("/Users/shashankawasthi/Documents/Project/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.yaml");
        Gateway.Builder builder = Gateway.createBuilder();
        builder.identity(wallet, "appUser").networkConfig(networkConfigPath).discovery(true);

        // create a gateway connection
        try (Gateway gateway = builder.connect()) {

            // get the network and contract

            Network network = gateway.getNetwork("mychannel");
            Contract contract = network.getContract("basic");

            byte result[];

            result = contract.evaluateTransaction("queryWalletCreditTrxn", transactionId);


            System.out.println(result);

            String s = new String(result);
            return s;

        }
    }

//    public String test() throws Exception {
//
//        // Load a file system based wallet for managing identities.
//        Path walletPath = Paths.get("wallet");
//        Wallet wallet = Wallets.newFileSystemWallet(walletPath);
//        // load a CCP
//        Path networkConfigPath = Paths.
//                get("/Users/shashankawasthi/Documents/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json");
//        Gateway.Builder builder = Gateway.createBuilder();
//        builder.identity(wallet, "admin").networkConfig(networkConfigPath).discovery(true);
//
//        // create a gateway connection
//        try (Gateway gateway = builder.connect()) {
//
//            // get the network and contract
//
//            Network network = gateway.getNetwork("mychannel");
//            Contract contract = network.getContract("basic");
//
//            byte result[];
//
////            result = contract.submitTransaction("Init");
//
//            /*byte[] pdfRawData;
//
//                pdfRawData = FileUtils.readFileToByteArray(new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/Passport.pdf"));
//                BASE64Encoder encoder = new BASE64Encoder();
//                String encodedPdf = encoder.encode(pdfRawData);
//
//                pdfHash pdfHash = new pdfHash();
//                MessageDigest md = MessageDigest.getInstance("SHA-256"); //SHA, MD2, MD5, SHA-256, SHA-384...
//                String hex = pdfHash.checksum("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/Passport.pdf", md);
//
//                Date d = new Date();
//                String date = String.valueOf(d.getDate());
//                result = contract.submitTransaction("insertCertificate", "12345", hex, encodedPdf,"Shashank",date);*/
//
//
//            /*result = contract.evaluateTransaction("GetCertificate", "12345");
//                System.out.println(result);
//
//                String s = new String(result);
//
//            JSONObject json = new JSONObject(s);
//            String document = json.getString("Document");
//            BASE64Decoder decoder = new BASE64Decoder();
//            FileUtils.writeByteArrayToFile(new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/shashankPassport.pdf") , decoder.decodeBuffer(document));*/
//
////            result = contract.evaluateTransaction("GetCertificateHistory", "12345");
////
//
//            result = contract.evaluateTransaction("GetCertificate", "12345");
//            System.out.println(result);
//
//            String s = new String(result);
//
//            JSONObject json = new JSONObject(s);
//            String createdBy = json.getString("CreatedBy");
//            String createdAt = json.getString("CreatedAt");
//
//
//            byte[] pdfRawData;
//            pdfRawData = FileUtils.readFileToByteArray(new File("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/Passport.pdf"));
//            BASE64Encoder encoder = new BASE64Encoder();
//            String encodedPdf = encoder.encode(pdfRawData);
//
//            pdfHash pdfHash = new pdfHash();
//            MessageDigest md = MessageDigest.getInstance("SHA-256"); //SHA, MD2, MD5, SHA-256, SHA-384...
//            String hex = pdfHash.checksum("/Users/shashankawasthi/Downloads/demo/src/main/java/xtras/Passport.pdf", md);
//
//            contract.submitTransaction("modifyCertificate", "12345", hex, encodedPdf, createdBy, createdAt, "Suraj", "modifiedtime");
//
//
////            String s = new String(result);
//            return s;
//
//        }
//    }


        public String test() throws Exception {

            // Load a file system based wallet for managing identities.
            Path walletPath = Paths.get("wallet");
            Wallet wallet = Wallets.newFileSystemWallet(walletPath);
            // load a CCP
            Path networkConfigPath = Paths.
                    get("/Users/shashankawasthi/Documents/fabric-samples/test-network/organizations/peerOrganizations/org1.example.com/connection-org1.json");
            Gateway.Builder builder = Gateway.createBuilder();
            builder.identity(wallet, "admin").networkConfig(networkConfigPath).discovery(true);

            // create a gateway connection
            try (Gateway gateway = builder.connect()) {

                // get the network and contract

                Network network = gateway.getNetwork("mychannel");
                Contract contract = network.getContract("basic");

                byte result[];

//                result = contract.submitTransaction("createRecord", "12345","Prashant","Male","23/11/1993","14:00","Kanpur","India","123-456-234","Kavita","Berendra","1234-3245-5432","222-3333-4444","","10/108","Ghaziabad","UP","India","201002","Hindu","createTime","createdBy");
//                result = contract.evaluateTransaction("queryAllRecords" );
//                result = contract.evaluateTransaction("queryRecordByRegNumber", "12345");
//                result = contract.submitTransaction("modifyRecord", "12345","Prakhar","Male","23/11/1993","14:00","Kanpur","India","123-456-234","Kavita","Berendra","1234-3245-5432","222-3333-4444","","10/108","Ghaziabad","UP","India","201002","Hindu","modifyTime","modBy");
//                result = contract.submitTransaction("approveRecord", "12345","dochash");
                result = contract.evaluateTransaction("ReadAsset", "asset1");




//                result = contract.evaluateTransaction("com.tequre.blockchain.wallet:create", "1234","555","type","status");




                String s = new String(result);
                System.out.println(s);
                return s;

            }
        }



}
