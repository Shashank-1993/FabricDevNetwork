/*
SPDX-License-Identifier: Apache-2.0
*/

package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

// SmartContract provides functions for managing a asset
type SmartContract struct {
	contractapi.Contract
}

// asset describes basic details of what makes up a asset
type asset struct {
	ID                  string `json:"id"`
	RequestorName       string `json:"requestorName"`
	BankName            string `json:"bankName"`
	BranchName          string `json:"branchName"`
	BankGuaranteeNumber string `json:"bankGuaranteeNumberstring"`
	DateOfIssue         string `json:"dateOfIssue"`
	ExpiryDate          string `json:"expiryDate"`
	ClaimExpiryDate     string `json:"claimExpiryDate"`
	ProjectName         string `json:"projectName"`
	LOA_Number          string `json:"LOA_Number"`
	BeneficiaryDecision string `json:"beneficiaryDecision"`
	BankDecision        string `json:"bankDecision"`
	AmountGuaranted     string `json:"amountGuaranted"`
	CreatedBy           string `json:"createdBy"`
	CreatedAt           string `json:"createdAt"`
	ModifiedBy          string `json:"modifiedBy"`
	ModifiedAt          string `json:"modifiedAt"`
	BankApprover        string `json:"bankApprover"`
}

// QueryResult structure used for handling result of query
type QueryResult struct {
	Key    string `json:"Key"`
	Record *asset
}

// InitLedger adds a base set of assets to the ledger
// func (s *SmartContract) InitLedger(ctx contractapi.TransactionContextInterface) error {
// 	assets := []asset{
// 		asset{Make: "Toyota", Model: "Prius", Colour: "blue", Owner: "Tomoko"},
// 		asset{Make: "Ford", Model: "Mustang", Colour: "red", Owner: "Brad"},
// 		asset{Make: "Hyundai", Model: "Tucson", Colour: "green", Owner: "Jin Soo"},
// 		asset{Make: "Volkswagen", Model: "Passat", Colour: "yellow", Owner: "Max"},
// 		asset{Make: "Tesla", Model: "S", Colour: "black", Owner: "Adriana"},
// 		asset{Make: "Peugeot", Model: "205", Colour: "purple", Owner: "Michel"},
// 		asset{Make: "Chery", Model: "S22L", Colour: "white", Owner: "Aarav"},
// 		asset{Make: "Fiat", Model: "Punto", Colour: "violet", Owner: "Pari"},
// 		asset{Make: "Tata", Model: "Nano", Colour: "indigo", Owner: "Valeria"},
// 		asset{Make: "Holden", Model: "Barina", Colour: "brown", Owner: "Shotaro"},
// 	}

// 	for i, asset := range assets {
// 		assetAsBytes, _ := json.Marshal(asset)
// 		err := ctx.GetStub().PutState("asset"+strconv.Itoa(i), assetAsBytes)

// 		if err != nil {
// 			return fmt.Errorf("Failed to put to world state. %s", err.Error())
// 		}
// 	}

// 	return nil
// }

// Createasset adds a new asset to the world state with given details
func (s *SmartContract) Createasset(ctx contractapi.TransactionContextInterface,
	id string,
	requestorName string,
	bankName string,
	branchName string,
	bankGuaranteeNumber string,
	dateOfIssue string,
	expiryDate string,
	claimExpiryDate string,
	projectName string,
	LOA_Number string,
	beneficiaryDecision string,
	bankDecision string,
	amountGuaranted string) error {

	asset := asset{
		ID:                  id,
		RequestorName:       requestorName,
		BankName:            bankName,
		BranchName:          branchName,
		BankGuaranteeNumber: bankGuaranteeNumber,
		DateOfIssue:         dateOfIssue,
		ExpiryDate:          expiryDate,
		ClaimExpiryDate:     claimExpiryDate,
		ProjectName:         projectName,
		LOA_Number:          LOA_Number,
		BeneficiaryDecision: beneficiaryDecision,
		BankDecision:        bankDecision,
		AmountGuaranted:     amountGuaranted,
	}

	assetAsBytes, _ := json.Marshal(asset)

	return ctx.GetStub().PutState(id, assetAsBytes)
}

// Queryasset returns the asset stored in the world state with given id
func (s *SmartContract) Queryasset(ctx contractapi.TransactionContextInterface, id string) (*asset, error) {
	assetAsBytes, err := ctx.GetStub().GetState(id)

	if err != nil {
		return nil, fmt.Errorf("Failed to read from world state. %s", err.Error())
	}

	if assetAsBytes == nil {
		return nil, fmt.Errorf("%s does not exist", id)
	}

	asset := new(asset)
	_ = json.Unmarshal(assetAsBytes, asset)

	return asset, nil
}

// QueryAllassets returns all assets found in world state
func (s *SmartContract) QueryAllassets(ctx contractapi.TransactionContextInterface) ([]QueryResult, error) {
	startKey := ""
	endKey := ""

	resultsIterator, err := ctx.GetStub().GetStateByRange(startKey, endKey)

	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	results := []QueryResult{}

	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()

		if err != nil {
			return nil, err
		}

		asset := new(asset)
		_ = json.Unmarshal(queryResponse.Value, asset)

		queryResult := QueryResult{Key: queryResponse.Key, Record: asset}
		results = append(results, queryResult)
	}

	return results, nil
}

// ChangeassetOwner updates the owner field of asset with given id in world state
// func (s *SmartContract) ChangeassetOwner(ctx contractapi.TransactionContextInterface, ID string, newOwner string) error {
// 	asset, err := s.Queryasset(ctx, ID)

// 	if err != nil {
// 		return err
// 	}

// 	asset.Owner = newOwner

// 	assetAsBytes, _ := json.Marshal(asset)

// 	return ctx.GetStub().PutState(ID, assetAsBytes)
// }

func main() {

	chaincode, err := contractapi.NewChaincode(new(SmartContract))

	if err != nil {
		fmt.Printf("Error create BGasset chaincode: %s", err.Error())
		return
	}

	if err := chaincode.Start(); err != nil {
		fmt.Printf("Error starting BGasset chaincode: %s", err.Error())
	}
}
