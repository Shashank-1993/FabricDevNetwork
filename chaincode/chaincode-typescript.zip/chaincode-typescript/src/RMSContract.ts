import {Context, Contract, Info, Returns, Transaction} from 'fabric-contract-api';
import {RecordDetails} from './RecordDetails';

@Info({title: 'NDMC-RMS', description: 'Smart contract for record management'})
export class RMSContract extends Contract {

    @Transaction()
    public async Init(ctx: Context): Promise<void> {
        console.info(`RMS-Contract initialized Successfully`);
    }

    // CreateRecord issues a new record to the world state with given details.
    @Transaction()
    public async createRecord(ctx: Context, 
        registrationNumber: string, 
        childName: string, 
        gender: string, 
        dateOfBirth: string,
        timeOfBirth: string, 
        cityOfBirth: string, 
        countryOfBirth: string, 
        childAadharNumber: string,
        motherName: string, 
        fatherName: string, 
        motherAadharNumber: string, 
        fatherAadharNumber: string,
        gurdianAadharNumber: string,
        address: string,
        city: string, 
        state: string, 
        country: string, 
        postalCode: string,
        religion: string,
        createdAt: string, 
        createdBy: string): Promise<RecordDetails> {
        const recordEntity = {
            RegistrationNumber: registrationNumber,
            ChildName: childName,
            Gender: gender,
            DateOfBirth: dateOfBirth,
            TimeOfBirth: timeOfBirth,
            CityOfBirth: cityOfBirth,
            CountryOfBirth: countryOfBirth,
            ChildAadharNumber: childAadharNumber,
            MotherName: motherName,
            FatherName: fatherName,
            MotherAadharNumber: motherAadharNumber,
            FatherAadharNumber: fatherAadharNumber,
            GurdianAadharNumber: gurdianAadharNumber,
            Address: address,
            City: city,
            State: state,
            Country: country,
            PostalCode: postalCode,
            Religion: religion,
            CreatedBy:createdBy,
            CreatedAt:createdAt,
            Status:'INITIALISED',
            ModifiedBy: '',
            ModifiedAt: ''
        // docType: 'birth-record'
        };
        await ctx.stub.putState(registrationNumber, Buffer.from(JSON.stringify(recordEntity)));
        return recordEntity;
    }

    // ModifyRecord modifies existing record with given details.
    @Transaction()
    public async modifyRecord(ctx: Context, 
        registrationNumber: string, 
        childName: string, 
        gender: string, 
        dateOfBirth: string,
        timeOfBirth: string, 
        cityOfBirth: string, 
        countryOfBirth: string, 
        childAadharNumber: string,
        motherName: string, 
        fatherName: string,
        motherAadharNumber: string, 
        fatherAadharNumber: string,
        gurdianAadharNumber: string, 
        address: string,
        city: string, 
        state: string, 
        country: string, 
        postalCode: string,
        religion: string,
        modifiedBy:string,
        modifiedAt:string): Promise<string> {

            const recordState = await ctx.stub.getState(registrationNumber); // get the record from chaincode state
        if (!recordState || recordState.length === 0) {
            throw new Error(`The record ${registrationNumber} does not exist`);
        }

        let recordJSON = JSON.parse(recordState.toString());

        const record = {
            RegistrationNumber: registrationNumber,
            ChildName: childName,
            Gender: gender,
            DateOfBirth: dateOfBirth,
            TimeOfBirth: timeOfBirth,
            CityOfBirth: cityOfBirth,
            CountryOfBirth: countryOfBirth,
            ChildAadharNumber: childAadharNumber,
            MotherName: motherName,
            FatherName: fatherName,
            MotherAadharNumber: motherAadharNumber,
            FatherAadharNumber: fatherAadharNumber,
            GurdianAadharNumber: gurdianAadharNumber,
            Address: address,
            City: city,
            State: state,
            Country: country,
            Religion: religion,
            PostalCode: postalCode,
            CreatedBy:recordJSON.CreatedBy,
            CreatedAt:recordJSON.CreatedAt,
            ModifiedAt: modifiedAt,
            ModifiedBy: modifiedBy,
            Status:'UPDATED',
        };
        await ctx.stub.putState(registrationNumber, Buffer.from(JSON.stringify(record)));

        return 'Modified Successfully';
    }

    // Approve record 
    @Transaction(true)
    public async approveRecord(ctx: Context,registrationNumber: string,docHash: string): Promise<string>{
        const recordState = await ctx.stub.getState(registrationNumber); // get the record from chaincode state
        const recordJSON = JSON.parse(recordState.toString());
        if (!recordState || recordState.length === 0) {
            throw new Error(`The record ${registrationNumber} does not exist`);
        }
        else{
            recordJSON.Status = 'APPROVED';
            recordJSON.DocHash = docHash;
            await ctx.stub.putState(registrationNumber, Buffer.from(JSON.stringify(recordJSON)));
        }
        return 'Approved Successfully';
    }

    // queryRecordByRegNumber returns the record stored in the world state with given registrationNumber.
    @Transaction(false)
    public async queryRecordByRegNumber(ctx: Context, 
        registrationNumber: string): Promise<string> {

        const recordState = await ctx.stub.getState(registrationNumber); // get the record from chaincode state
        if (!recordState || recordState.length === 0) {
            throw new Error(`The record ${registrationNumber} does not exist`);
        }

        const strValue = Buffer.from(recordState).toString('utf8');
        let recordInJsonArrayForm = `[${strValue}]`;

        let recordJSON = JSON.parse(recordInJsonArrayForm);

        console.log(recordJSON);
        return recordJSON;

    }

    @Transaction(false)
    public async queryAllRecords(ctx: Context): Promise<string> {
        const startKey = '';
        const endKey = '';
        const allResults = [];
        for await (const {key, value} of ctx.stub.getStateByRange(startKey, endKey)) {
            const strValue = Buffer.from(value).toString('utf8');
            allResults.push(JSON.parse(strValue));
        }
        console.info(allResults);        
        return JSON.stringify(allResults);
    }

    // @Transaction()
    // async insertCertificate(ctx : Context,
    //     registrationNumber:string,
    //     docHash:String,
    //     document:String,
    //     createdBy:String,
    //     createdAt:String): Promise<String>  {

    //         if(!registrationNumber){
    //             throw new Error('Registration_Number cannot be null');
    //         }

    //         if(!docHash){
    //             throw new Error('Certificate Hash cannot be null');
    //         }

    //         if(!document){
    //             throw new Error('Please input document');
    //         }

    //         let certificateEntity = {
    //             RegistrationNumber : registrationNumber,
    //             DocHash : docHash,
    //             Document : document,
    //             CreatedBy:createdBy,
    //             CreatedAt:createdAt
                
    //         }

    //     await ctx.stub.putState(registrationNumber,Buffer.from(JSON.stringify(certificateEntity)));
    //     return 'Document Persisted Successfully';
    // }

    // @Transaction()
    // async modifyCertificate(ctx : Context,
    //     registrationNumber:string,
    //     docHash:String,
    //     document:String,
    //     createdBy:String,
    //     createdAt:String,
    //     modifiedBy:String,
    //     modifiedAt:String): Promise<String>  {

    //         if(!registrationNumber){
    //             throw new Error('Registration_Number cannot be null');
    //         }

    //         if(!docHash){
    //             throw new Error('Certificate Hash cannot be null');
    //         }

    //         if(!document){
    //             throw new Error('Please input document');
    //         }

    //         let certificateEntity = {
    //             RegistrationNumber : registrationNumber,
    //             DocHash : docHash,
    //             Document : document,
    //             CreatedBy:createdBy,
    //             CreatedAt:createdAt,
    //             ModifiedBy:modifiedBy,
    //             ModifiedAt:modifiedAt
                
    //         }

    //     await ctx.stub.putState(registrationNumber,Buffer.from(JSON.stringify(certificateEntity)));
    //     return 'Modified document Persisted Successfully';
    // }

    // GetRecordHistory returns the record history stored ledger with given registrationNumber.
   
    @Transaction(false)
    public async getRecordHistory(ctx: Context, registrationNumber: string): Promise<string> {
        const recordJSON = await ctx.stub.getHistoryForKey(registrationNumber); // get the record from chaincode state
        if (!recordJSON) {
            throw new Error(`The record ${registrationNumber} does not exist`);
        }

        const promiseOfIterator = ctx.stub.getHistoryForKey(registrationNumber);

        const results = [];
        for await (const keyMod of promiseOfIterator) {
            const resp = {
                timestamp: keyMod.timestamp,
                txid: keyMod.txId,
                data: ''
            }
            if (keyMod.isDelete) {
                resp.data = 'KEY DELETED';
            } else {
                resp.data = JSON.parse(keyMod.value.toString());
            }
            results.push(JSON.parse(JSON.stringify(resp)));
        }

        console.log(results)
        return JSON.stringify(results);
    }

}
