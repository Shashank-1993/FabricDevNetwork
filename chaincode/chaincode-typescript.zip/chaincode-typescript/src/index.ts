/*
 * SPDX-License-Identifier: Apache-2.0
 */

import {RMSContract} from './RMSContract';

export {RMSContract} from './RMSContract';

export const contracts: any[] = [RMSContract];
