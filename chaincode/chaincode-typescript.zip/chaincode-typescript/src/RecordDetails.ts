import {Object, Property} from 'fabric-contract-api';

@Object()
export class RecordDetails {
    // @Property()
    // public docType?: string;

    @Property()
    public RegistrationNumber: string;

    @Property()
    public ChildName: string;

    @Property()
    public Gender: string;

    @Property()
    public DateOfBirth: string;

    @Property()
    public TimeOfBirth: string;

    @Property()
    public CityOfBirth: string;

    @Property()
    public CountryOfBirth: string;

    @Property()
    public ChildAadharNumber: string;

    // Parents details
    @Property()
    public MotherName: string;

    @Property()
    public FatherName: string;

    @Property()
    public MotherAadharNumber: string;

    @Property()
    public FatherAadharNumber: string;

    @Property()
    public GurdianAadharNumber: string;

    @Property()
    public Address: string;

    @Property()
    public City: string;

    @Property()
    public State: string;

    @Property()
    public Country: string;

    @Property()
    public PostalCode: string;

    @Property()
    public Religion: string;

    @Property()
    public Status: string;    // Pending or Approved 

    @Property()
    public CreatedAt: string;

    @Property()
    public CreatedBy: string;

    @Property()
    public ModifiedAt: string;

    @Property()
    public ModifiedBy: string;

}
